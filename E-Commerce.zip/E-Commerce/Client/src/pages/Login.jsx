import { useState } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import API from '../services/api.js'

function Login({ onLogin }) {
  const navigate = useNavigate()
  const location = useLocation()
  const [formData, setFormData] = useState({ email: '', password: '' })
  const [message, setMessage] = useState({ type: '', text: '' })
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleChange = (event) => {
    setFormData({ ...formData, [event.target.name]: event.target.value })
  }

  const handleSubmit = async (event) => {
    event.preventDefault()
    setMessage({ type: '', text: '' })
    setIsSubmitting(true)

    try {
      const response = await API.post('/auth/login', formData)
      localStorage.setItem('shopEaseToken', response.data.token)
      localStorage.setItem('shopEaseUser', JSON.stringify(response.data.user))
      onLogin(response.data.user)
      setMessage({ type: 'success', text: response.data.message })
      navigate(response.data.user.role === 'admin' ? '/admin' : location.state?.from || '/')
    } catch (error) {
      setMessage({ type: 'error', text: error.response?.data?.message || 'Login failed.' })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <section className="auth-page container">
      <div className="auth-card">
        <p className="eyebrow">Welcome back</p>
        <h1>Pick up where you left off.</h1>
        <p className="auth-copy">Sign in to revisit your saved finds.</p>
        {message.text && <div className={`feedback feedback-${message.type}`} role="alert">{message.text}</div>}
        <form onSubmit={handleSubmit} className="auth-form">
          <label htmlFor="login-email">Email address</label>
          <input id="login-email" name="email" type="email" value={formData.email} onChange={handleChange} autoComplete="email" required />
          <label htmlFor="login-password">Password</label>
          <input id="login-password" name="password" type="password" value={formData.password} onChange={handleChange} autoComplete="current-password" required />
          <button className="button button-primary" type="submit" disabled={isSubmitting}>{isSubmitting ? 'Signing in...' : 'Sign in'}</button>
        </form>
        <p className="auth-switch">New here? <Link to="/register">Create an account</Link></p>
      </div>
    </section>
  )
}

export default Login
