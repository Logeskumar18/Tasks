import { Link } from 'react-router-dom'

function Cart({ cart, onUpdate, onRemove }) {
  const total = cart.reduce((sum, item) => sum + Number(item.price) * item.quantity, 0)

  return (
    <section className="cart-page container">
      <div className="page-heading"><div><p className="eyebrow">Your selection</p><h1>Shopping cart.</h1></div><p>{cart.length} {cart.length === 1 ? 'item' : 'items'}</p></div>
      {cart.length === 0 ? <div className="empty-page"><p>Your cart is waiting for something special.</p><Link to="/products" className="button button-dark">Explore collection</Link></div> : <div className="cart-layout"><div className="cart-items">{cart.map((item) => <article className="cart-item" key={item.id}><img src={item.image_url} alt={item.name} /><div className="cart-item-copy"><h2>{item.name}</h2><p>{item.storage} · {item.color}</p><strong>${Number(item.price).toLocaleString()}</strong></div><div className="quantity-control"><button type="button" onClick={() => onUpdate(item.id, item.quantity - 1)} aria-label="Decrease quantity">−</button><span>{item.quantity}</span><button type="button" onClick={() => onUpdate(item.id, item.quantity + 1)} aria-label="Increase quantity">+</button></div><button className="remove-button" type="button" onClick={() => onRemove(item.id)}>Remove</button></article>)}</div><aside className="summary"><p>Order summary</p><div><span>Subtotal</span><strong>${total.toLocaleString()}</strong></div><div><span>Delivery</span><span>Free</span></div><hr /><div className="summary-total"><span>Total</span><strong>${total.toLocaleString()}</strong></div><Link to="/checkout" className="button button-dark">Continue to checkout</Link></aside></div>}
    </section>
  )
}

export default Cart
