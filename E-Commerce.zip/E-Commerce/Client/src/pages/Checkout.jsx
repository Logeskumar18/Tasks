import { useState } from 'react'
import { Link } from 'react-router-dom'
import API from '../services/api.js'

function Checkout({ cart, onOrder }) {
  const [complete, setComplete] = useState(false)
  const [form, setForm] = useState({ name: '', address: '', city: '', postalCode: '' })
  const total = cart.reduce((sum, item) => sum + Number(item.price) * item.quantity, 0)

  const submit = async (event) => { event.preventDefault(); try { await API.post('/orders', { total, items: cart, shippingName: form.name, shippingAddress: form.address, shippingCity: form.city, shippingPostalCode: form.postalCode }); onOrder({ ...form, total, items: cart }); setComplete(true) } catch { setComplete(false) } }
  if (complete) return <section className="empty-page container"><p className="eyebrow">Order confirmed</p><h1>Thank you for your order.</h1><p>Your order has been placed successfully.</p><Link className="button button-dark" to="/orders">View orders</Link></section>

  return <section className="checkout-page container"><p className="eyebrow">Almost yours</p><h1>Checkout.</h1><div className="checkout-layout"><form className="checkout-form" onSubmit={submit}><label>Full name<input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required /></label><label>Address<input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} required /></label><div className="split-fields"><label>City<input value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} required /></label><label>Postal code<input value={form.postalCode} onChange={(e) => setForm({ ...form, postalCode: e.target.value })} required /></label></div><button className="button button-dark" type="submit" disabled={!cart.length}>Place order · ${total.toLocaleString()}</button></form></div></section>
}

export default Checkout
