import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import API from '../services/api.js'

function Orders({ orders }) {
  const [remoteOrders, setRemoteOrders] = useState(orders)
  useEffect(() => { API.get('/orders').then(({ data }) => setRemoteOrders(data.orders)).catch(() => {}) }, [])
  return <section className="orders-page container"><p className="eyebrow">Your history</p><h1>My orders.</h1>{remoteOrders.length === 0 ? <div className="empty-page"><p>Your completed orders will appear here.</p><Link className="button button-dark" to="/products">Browse products</Link></div> : <div className="orders-list">{remoteOrders.map((order, index) => <article className="order-row" key={order.id || `${order.total}-${index}`}><div><strong>Order #{String(order.id || index + 1).padStart(4, '0')}</strong><p>{Array.isArray(order.items) ? order.items.length : JSON.parse(order.items || '[]').length} items · {order.shipping_city || order.city}</p></div><strong>${Number(order.total).toLocaleString()}</strong></article>)}</div>}</section>
}

export default Orders
