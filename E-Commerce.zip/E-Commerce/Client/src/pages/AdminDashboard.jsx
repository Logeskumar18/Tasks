import { useEffect, useState } from 'react'
import API from '../services/api.js'

const emptyProduct = { name: '', category: 'iPhone', storage: '', color: '', description: '', price: '', image_url: '', stock: 0, featured: false }

function AdminDashboard() {
  const [activeTab, setActiveTab] = useState('overview')
  const [stats, setStats] = useState({ users: 0, products: 0, orders: 0, revenue: 0 })
  const [users, setUsers] = useState([])
  const [products, setProducts] = useState([])
  const [orders, setOrders] = useState([])
  const [productForm, setProductForm] = useState(emptyProduct)
  const [message, setMessage] = useState('')

  const loadData = async () => {
    const [statsResponse, usersResponse, productsResponse, ordersResponse] = await Promise.all([API.get('/admin/stats'), API.get('/admin/users'), API.get('/admin/products'), API.get('/admin/orders')])
    setStats(statsResponse.data.stats); setUsers(usersResponse.data.users); setProducts(productsResponse.data.products); setOrders(ordersResponse.data.orders)
  }
  useEffect(() => { loadData().catch((error) => setMessage(error.response?.data?.message || 'Unable to load admin data.')) }, [])

  const createProduct = async (event) => {
    event.preventDefault()
    try { await API.post('/admin/products', { ...productForm, price: Number(productForm.price), stock: Number(productForm.stock) }); setProductForm(emptyProduct); setMessage('Product created.'); await loadData() } catch (error) { setMessage(error.response?.data?.message || 'Unable to create product.') }
  }
  const updateRole = async (id, role) => { await API.patch(`/admin/users/${id}/role`, { role }); await loadData() }
  const deleteUser = async (id) => { if (window.confirm('Delete this customer?')) { await API.delete(`/admin/users/${id}`); await loadData() } }
  const deleteProduct = async (id) => { if (window.confirm('Delete this product?')) { await API.delete(`/admin/products/${id}`); await loadData() } }
  const updateStatus = async (id, status) => { await API.patch(`/admin/orders/${id}/status`, { status }); await loadData() }

  return <section className="admin-page container"><div className="admin-heading"><div><p className="eyebrow">Operations</p><h1>Admin dashboard.</h1></div><span className="admin-badge">Administrator</span></div>{message && <p className="admin-message">{message}</p>}<nav className="admin-tabs" aria-label="Admin sections">{['overview', 'products', 'users', 'orders'].map((tab) => <button className={activeTab === tab ? 'active' : ''} key={tab} type="button" onClick={() => setActiveTab(tab)}>{tab}</button>)}</nav>{activeTab === 'overview' && <div className="stat-grid">{[['Users', stats.users], ['Products', stats.products], ['Orders', stats.orders], ['Revenue', `$${Number(stats.revenue).toLocaleString()}`]].map(([label, value]) => <article className="stat-card" key={label}><p>{label}</p><strong>{value}</strong></article>)}</div>}{activeTab === 'products' && <div className="admin-section"><form className="admin-product-form" onSubmit={createProduct}><h2>Add product</h2>{[['name', 'Name'], ['storage', 'Storage'], ['color', 'Color'], ['price', 'Price'], ['image_url', 'Image URL']].map(([key, label]) => <label key={key}>{label}<input required={key !== 'image_url'} value={productForm[key]} onChange={(e) => setProductForm({ ...productForm, [key]: e.target.value })} /></label>)}<label>Description<textarea required value={productForm.description} onChange={(e) => setProductForm({ ...productForm, description: e.target.value })} /></label><label>Stock<input type="number" min="0" value={productForm.stock} onChange={(e) => setProductForm({ ...productForm, stock: e.target.value })} /></label><button className="button button-dark" type="submit">Add product</button></form><div className="admin-table-wrap"><h2>Catalogue</h2><table className="admin-table"><thead><tr><th>Product</th><th>Price</th><th>Stock</th><th /></tr></thead><tbody>{products.map((product) => <tr key={product.id}><td>{product.name}</td><td>${Number(product.price).toLocaleString()}</td><td>{product.stock}</td><td><button className="table-action danger" type="button" onClick={() => deleteProduct(product.id)}>Delete</button></td></tr>)}</tbody></table></div></div>}{activeTab === 'users' && <div className="admin-table-wrap"><h2>Customers</h2><table className="admin-table"><thead><tr><th>Name</th><th>Email</th><th>Role</th><th /></tr></thead><tbody>{users.map((user) => <tr key={user.id}><td>{user.name}</td><td>{user.email}</td><td><select value={user.role} onChange={(e) => updateRole(user.id, e.target.value)}><option value="customer">Customer</option><option value="admin">Admin</option></select></td><td><button className="table-action danger" type="button" onClick={() => deleteUser(user.id)}>Delete</button></td></tr>)}</tbody></table></div>}{activeTab === 'orders' && <div className="admin-table-wrap"><h2>Orders</h2><table className="admin-table"><thead><tr><th>Order</th><th>Customer</th><th>Total</th><th>Status</th></tr></thead><tbody>{orders.map((order) => <tr key={order.id}><td>#{order.id}</td><td>{order.customer_name}<br /><small>{order.customer_email}</small></td><td>${Number(order.total).toLocaleString()}</td><td><select value={order.status} onChange={(e) => updateStatus(order.id, e.target.value)}>{['pending', 'processing', 'shipped', 'delivered', 'cancelled'].map((status) => <option key={status}>{status}</option>)}</select></td></tr>)}</tbody></table></div>}</section>
}

export default AdminDashboard
