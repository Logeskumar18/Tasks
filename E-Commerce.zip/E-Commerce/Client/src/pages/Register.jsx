import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import API from '../services/api.js'

function Register() {
  const navigate = useNavigate()
  const [formData, setFormData] = useState({ name: '', email: '', password: '' })
  const [message, setMessage] = useState({ type: '', text: '' })
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleChange = (event) => {
    setFormData({ ...formData, [event.target.name]: event.target.value })
  }

  const handleSubmit = async (event) => {
    event.preventDefault()
    setMessage({ type: '', text: '' })
    setIsSubmitting(true)

    try {
      const response = await API.post('/auth/register', formData)
      setMessage({ type: 'success', text: response.data.message })
      setTimeout(() => navigate('/login'), 900)
    } catch (error) {
      setMessage({ type: 'error', text: error.response?.data?.message || 'Registration failed.' })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <section className="auth-page container">
      <div className="auth-card">
        <p className="eyebrow">New account</p>
        <h1>Make room for what you love.</h1>
        <p className="auth-copy">Create an account to keep your favorites close.</p>
        {message.text && <div className={`feedback feedback-${message.type}`} role="alert">{message.text}</div>}
        <form onSubmit={handleSubmit} className="auth-form">
          <label htmlFor="register-name">Full name</label>
          <input id="register-name" name="name" type="text" value={formData.name} onChange={handleChange} autoComplete="name" required />
          <label htmlFor="register-email">Email address</label>
          <input id="register-email" name="email" type="email" value={formData.email} onChange={handleChange} autoComplete="email" required />
          <label htmlFor="register-password">Password</label>
          <input id="register-password" name="password" type="password" value={formData.password} onChange={handleChange} autoComplete="new-password" minLength="8" required />
          <button className="button button-primary" type="submit" disabled={isSubmitting}>{isSubmitting ? 'Creating account...' : 'Create account'}</button>
        </form>
        <p className="auth-switch">Already have an account? <Link to="/login">Sign in</Link></p>
      </div>
    </section>
  )
}

export default Register
