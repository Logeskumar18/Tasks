import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import ProductCard from '../components/ProductCard.jsx'
import API from '../services/api.js'

function Products({ onAdd, isAuthenticated }) {
  const navigate = useNavigate()
  const [products, setProducts] = useState([])
  const [status, setStatus] = useState('Loading the collection...')
  const handleAdd = (product) => {
    if (!isAuthenticated) return navigate('/login', { state: { from: '/products' } })
    onAdd(product)
  }

  useEffect(() => {
    API.get('/products')
      .then(({ data }) => {
        setProducts(data.products)
        setStatus('')
      })
      .catch(() => setStatus('The collection is unavailable right now.'))
  }, [])

  return (
    <section className="catalogue-page container">
      <div className="page-heading">
        <div><p className="eyebrow">The collection</p><h1>Explore the lineup.</h1></div>
        <p>Precision, power, and a finish worth keeping.</p>
      </div>
      {status && <p className="catalogue-status">{status}</p>}
      <div className="product-grid">{products.map((product) => <ProductCard key={product.id} product={product} onAdd={handleAdd} />)}</div>
    </section>
  )
}

export default Products
