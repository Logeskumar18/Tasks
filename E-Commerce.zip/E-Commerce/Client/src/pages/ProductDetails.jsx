import { useEffect, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import API from '../services/api.js'

function ProductDetails({ onAdd, isAuthenticated }) {
  const { id } = useParams()
  const navigate = useNavigate()
  const [product, setProduct] = useState(null)
  const [status, setStatus] = useState('Loading product...')

  useEffect(() => {
    API.get(`/products/${id}`)
      .then(({ data }) => { setProduct(data.product); setStatus('') })
      .catch(() => setStatus('Product not found.'))
  }, [id])

  if (!product) return <section className="empty-page container"><p>{status}</p><Link to="/products" className="button button-dark">Back to collection</Link></section>
  const handleAdd = () => {
    if (!isAuthenticated) return navigate('/login', { state: { from: `/products/${id}` } })
    onAdd(product)
  }

  return (
    <section className="detail-page container">
      <Link className="back-link" to="/products">← Back to collection</Link>
      <div className="detail-layout">
        <div className="detail-image-wrap"><img src={product.image_url} alt={product.name} className="detail-image" /></div>
        <div className="detail-copy">
          <p className="eyebrow">{product.category}</p>
          <h1>{product.name}</h1>
          <p className="detail-price">${Number(product.price).toLocaleString()}</p>
          <p className="detail-description">{product.description}</p>
          <dl className="spec-list"><div><dt>Storage</dt><dd>{product.storage}</dd></div><div><dt>Finish</dt><dd>{product.color}</dd></div><div><dt>Availability</dt><dd>{product.stock > 0 ? 'In stock' : 'Sold out'}</dd></div></dl>
          <button className="button button-dark" type="button" onClick={handleAdd} disabled={product.stock < 1}>Add to cart</button>
        </div>
      </div>
    </section>
  )
}

export default ProductDetails
