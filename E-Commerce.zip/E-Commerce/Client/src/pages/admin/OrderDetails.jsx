import { Link, useParams } from 'react-router-dom'
function OrderDetails() { const { id } = useParams(); return <section className="admin-content"><div className="admin-page-title"><p className="admin-kicker">Fulfilment</p><h1>Order #{id}</h1></div><p>Order details are managed from the Orders table.</p><Link className="button button-dark" to="/admin/orders">Back to orders</Link></section> }
export default OrderDetails
