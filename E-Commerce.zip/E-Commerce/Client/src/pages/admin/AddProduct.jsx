import ProductForm from './ProductForm.jsx'
function AddProduct() { return <section className="admin-content"><div className="admin-page-title"><p className="admin-kicker">Catalogue</p><h1>Add product</h1></div><ProductForm /></section> }
export default AddProduct
