import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import API from '../../services/api.js'
import ProductForm from './ProductForm.jsx'
function EditProduct() { const { id } = useParams(); const [product, setProduct] = useState(null); useEffect(() => { API.get(`/products/${id}`).then(({ data }) => setProduct(data.product)) }, [id]); return <section className="admin-content"><div className="admin-page-title"><p className="admin-kicker">Catalogue</p><h1>Edit product</h1></div>{product && <ProductForm initial={product} />}</section> }
export default EditProduct
