import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import API from '../../services/api.js'

function Products() {
  const [products, setProducts] = useState([]); const [query, setQuery] = useState('')
  const load = () => API.get('/admin/products').then(({ data }) => setProducts(data.products))
  useEffect(() => { load() }, [])
  const remove = async (id) => { if (window.confirm('Delete this product?')) { await API.delete(`/admin/products/${id}`); load() } }
  const filtered = products.filter((p) => p.name.toLowerCase().includes(query.toLowerCase()))
  return <section className="admin-content"><div className="admin-page-title admin-title-row"><div><p className="admin-kicker">Catalogue</p><h1>Products</h1></div><Link className="button button-dark" to="/admin/products/new">Add product</Link></div><input className="admin-search" placeholder="Search products" value={query} onChange={(e) => setQuery(e.target.value)} /><div className="admin-table-wrap"><table className="admin-table"><thead><tr><th>Product</th><th>Category</th><th>Price</th><th>Stock</th><th /></tr></thead><tbody>{filtered.map((p) => <tr key={p.id}><td>{p.name}</td><td>{p.category}</td><td>${Number(p.price).toLocaleString()}</td><td>{p.stock}</td><td><Link to={`/admin/products/${p.id}/edit`} className="table-action">Edit</Link><button className="table-action danger" onClick={() => remove(p.id)} type="button">Delete</button></td></tr>)}</tbody></table></div></section>
}
export default Products
