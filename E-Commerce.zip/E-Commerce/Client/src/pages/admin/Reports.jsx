import { useEffect, useState } from 'react'
import API from '../../services/api.js'
function Reports() { const [report, setReport] = useState([]); useEffect(() => { API.get('/admin/reports').then(({ data }) => setReport(data.report)) }, []); return <section className="admin-content"><div className="admin-page-title"><p className="admin-kicker">Performance</p><h1>Sales reports</h1></div><div className="admin-table-wrap"><table className="admin-table"><thead><tr><th>Month</th><th>Orders</th><th>Revenue</th></tr></thead><tbody>{report.map((row) => <tr key={row.month}><td>{row.month}</td><td>{row.orders}</td><td>₹{Number(row.revenue).toLocaleString('en-IN')}</td></tr>)}</tbody></table></div></section> }
export default Reports
