import { Link } from 'react-router-dom'
import Hero from '../components/Hero.jsx'

function Home() {
  return <><Hero /><section className="home-feature container"><div><p className="eyebrow">ShopEase.</p><h2>Considered technology.<br />Beautifully selected.</h2></div><Link className="text-link" to="/products">See all products <span>↗</span></Link></section></>
}

export default Home
