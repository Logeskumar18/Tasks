import { Navigate, Outlet } from 'react-router-dom'
import AdminNavbar from './AdminNavbar.jsx'
import AdminSidebar from './AdminSidebar.jsx'

function AdminLayout({ user, onLogout }) {
  if (user?.role !== 'admin') return <Navigate to="/login" replace />
  return <div className="admin-shell"><AdminSidebar /><div className="admin-main"><AdminNavbar user={user} onLogout={onLogout} /><Outlet /></div></div>
}

export default AdminLayout
