
function AdminNavbar({ user, onLogout }) {
  return (
    <nav className="navbar bg-white border-bottom shadow-sm px-3 px-lg-4 py-3 sticky-top">
      <div className="container-fluid">

        {/* Welcome */}
        <div>
          <p className="text-success fw-semibold text-uppercase small mb-1">
            <i className="bi bi-grid me-2"></i>
            Control Center
          </p>

          <h5 className="fw-bold text-dark mb-0">
            Welcome back, {user?.name || 'Admin'}!
          </h5>

          <small className="text-secondary">
            Manage your store with ease.
          </small>
        </div>

        {/* Admin Profile */}
        <div className="d-flex align-items-center gap-3">

          <div className="d-none d-sm-flex align-items-center gap-2">
            <div
              className="rounded-circle bg-success-subtle text-success fw-bold d-flex align-items-center justify-content-center"
              style={{ width: '42px', height: '42px' }}
            >
              {user?.name?.charAt(0)?.toUpperCase() || 'A'}
            </div>

            <div className="d-none d-md-block">
              <div className="fw-semibold text-dark">
                {user?.name || 'Admin'}
              </div>
              <small className="text-secondary">
                Administrator
              </small>
            </div>
          </div>

          <button
            type="button"
            className="btn btn-outline-danger rounded-pill btn-sm px-3 py-2 fw-semibold"
            onClick={onLogout}
          >
            <i className="bi bi-box-arrow-right me-2"></i>
            Log out
          </button>

        </div>
      </div>
    </nav>
  )
}

export default AdminNavbar
