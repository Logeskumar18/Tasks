import { NavLink } from 'react-router-dom'

const links = [['Dashboard', '/admin'], ['Products', '/admin/products'], ['Orders', '/admin/orders'], ['Customers', '/admin/customers'], ['Categories', '/admin/categories'], ['Sales Reports', '/admin/reports']]

function AdminSidebar() {
  return <aside className="admin-sidebar"><div className="admin-brand">ShopEase <span>ADMIN</span></div><nav>{links.map(([label, path]) => <NavLink key={path} to={path} end={path === '/admin'}>{label}</NavLink>)}</nav></aside>
}

export default AdminSidebar
