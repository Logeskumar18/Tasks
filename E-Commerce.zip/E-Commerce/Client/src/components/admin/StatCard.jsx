function StatCard({ label, value, note }) {
  return <article className="admin-stat-card"><p>{label}</p><strong>{value}</strong><small>{note}</small></article>
}

export default StatCard
