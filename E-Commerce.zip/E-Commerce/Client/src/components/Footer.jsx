
function Footer() {
  return (
    <footer className="site-footer">
      <div className="container">
        <div className="d-flex flex-column flex-sm-row align-items-center justify-content-between gap-2">
          <a href="/" className="footer-brand text-decoration-none">
            IPlant<span className="brand-dot">.</span>
          </a>

          <p className="footer-tagline mb-0">
            Thoughtful things, simply found.
          </p>

          <small className="footer-copyright">
            © {new Date().getFullYear()} IPlant. All rights reserved.
          </small>
        </div>
      </div>
    </footer>
  )
}

export default Footer
