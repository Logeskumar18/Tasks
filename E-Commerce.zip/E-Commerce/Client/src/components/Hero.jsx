import { Link } from 'react-router-dom'

function Hero() {
  return (
    <section className="hero-section container">
      <div className="hero-content">
        <p className="eyebrow">The next chapter</p>
        <h1>iPhone 18 Series</h1>
        <p>A new generation of possibilities.</p>
        <Link className="button button-dark" to="/products">Explore collection</Link>
      </div>
      <div className="hero-device" role="img" aria-label="iPhone 18 Series product photography">
        <div className="device-glow" />
        <div className="device-phone device-phone-back"><span className="camera-lens lens-one" /><span className="camera-lens lens-two" /><span className="camera-lens lens-three" /></div>
        <div className="device-phone device-phone-front" />
      </div>
    </section>
  )
}

export default Hero
