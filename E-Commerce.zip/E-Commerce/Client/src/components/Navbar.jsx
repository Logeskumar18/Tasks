import { Link, NavLink } from 'react-router-dom'

function Navbar({ cartCount = 0, isAuthenticated = false, isAdmin = false, onLogout }) {
  return (
    <nav className="site-nav navbar navbar-expand-md">
      <div className="container">
        <Link className="brand-mark navbar-brand" to="/">IPlant</Link>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#siteNav" aria-controls="siteNav" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon" />
        </button>
        <div className="collapse navbar-collapse" id="siteNav">
          <div className="navbar-nav ms-auto align-items-md-center gap-md-2">
            <NavLink className="nav-link" to="/">Home</NavLink>
            <NavLink className="nav-link" to="/products">Products</NavLink>
            <NavLink className="nav-link" to="/orders">Orders</NavLink>
            {isAdmin && <NavLink className="nav-link" to="/admin">Admin</NavLink>}
            {isAuthenticated ? <button className="nav-link nav-logout" type="button" onClick={onLogout}>Log out</button> : <NavLink className="nav-link" to="/login">Login</NavLink>}
            <NavLink className="nav-cart" to="/cart">Cart <span>{cartCount}</span></NavLink>
            <Link className="nav-cta" to="/register">Create account</Link>
          </div>
        </div>
      </div>
    </nav>
  )
}

export default Navbar
