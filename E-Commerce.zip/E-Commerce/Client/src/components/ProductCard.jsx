import { Link } from 'react-router-dom'

function ProductCard({ product, onAdd }) {
  return (
    <article className="product-card">
      <Link to={`/products/${product.id}`} className="product-image-wrap">
        <img src={product.image_url} alt={product.name} className="product-image" />
      </Link>
      <div className="product-info">
        <div>
          <p className="product-category">{product.category}</p>
          <h3><Link to={`/products/${product.id}`}>{product.name}</Link></h3>
          <p className="product-spec">{product.storage} · {product.color}</p>
        </div>
        <div className="product-bottom">
          <strong>${Number(product.price).toLocaleString()}</strong>
          <button type="button" className="icon-button" onClick={() => onAdd(product)} aria-label={`Add ${product.name} to cart`}>+</button>
        </div>
      </div>
    </article>
  )
}

export default ProductCard
